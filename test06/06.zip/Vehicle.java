package sec3;

public class Vehicle {
	public void run(){
		System.out.println("조종체가 움직입니다.");
	}
}
