package sec3;

public class Driver {
	public void drive(Vehicle vehicle){
		System.out.println("운전사에 의해 ");
		vehicle.run();
	}
}